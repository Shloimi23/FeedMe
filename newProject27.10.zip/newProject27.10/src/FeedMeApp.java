import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Enumeration;
import java.util.Vector;
import javax.swing.*;
import javax.swing.tree.*;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;

public class FeedMeApp extends JFrame implements ActionListener {

	JPanel mainPanel, upper, middle, leftPanel;
	JButton btnRemoveLast, btnSave; // הוספת כפתור מחיקה
	JMenuItem deleteAccountItem,removeLastFeet,save;
	JTextField txtAddURL;
	Vector<DataChannelPanel> datapanelVec;
	JScrollPane scroller;
	JScrollBar newbar;
	private JTree tree;
	DefaultMutableTreeNode root;
	DefaultMutableTreeNode nodeToAdd;
	private static boolean treeOrderChanged = false;
	private FeedDetailsObject feedObjectToServer, feedObjectFromServer;
	String action;
	String user;
	String password;
	private static UserObject userObject;
	private static Client client = new Client();
	// הגדרת שדה החיפוש וכפתור החיפוש
	private JTextField searchField;
	private JButton searchButton;

	public FeedMeApp(String s) {
		super(s);

		ToolTipManager.sharedInstance().setInitialDelay(200);
		ToolTipManager.sharedInstance().setDismissDelay(Integer.MAX_VALUE);
		action = "login";
		user = "default";
		password = "1";
		userObject = new UserObject(user, password, action);
		datapanelVec = new Vector<DataChannelPanel>();

		txtAddURL = new JTextField("Enter here a new feed and then press enter.");
		txtAddURL.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				nodeToAdd = new DefaultMutableTreeNode(txtAddURL.getText());
				DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
				node.add(nodeToAdd);
				DefaultTreeModel model = (DefaultTreeModel) tree.getModel();
				DefaultMutableTreeNode theroot = (DefaultMutableTreeNode) model.getRoot();
				model.reload(theroot);
				datapanelVec.addElement(new DataChannelPanel(txtAddURL.getText()));
				middle.add(datapanelVec.lastElement(), BorderLayout.NORTH);
				validate();
			}
		});

		// יצירת התפריט הראשי
		JMenuBar menuBar = new JMenuBar();

		// יצירת תפריט חדש בשם "חשבון"
		JMenu accountMenu = new JMenu("File");

		// יצירת אפשרות בתפריט למחיקת חשבון
		JMenuItem deleteAccountItem = new JMenuItem("Delete Account");
		JMenuItem removeLastFeet = new JMenuItem("Remove Last Feed");
		JMenuItem save = new JMenuItem("Save");

		// הוספת מאזין לאפשרות מחיקת חשבון
		deleteAccountItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				deleteAccount(); // קריאה לפונקציית מחיקת החשבון


			}
		});

		removeLastFeet.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				removeLast(); // קריאה לפונקציית מחיקת החשבון


			}
		});

		save.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				saveFeeds(); // קריאה לפונקציית מחיקת החשבון


			}
		});

		// הוספת האפשרות לתפריט "חשבון" והוספתו לתפריט הראשי
		accountMenu.add(deleteAccountItem);
		accountMenu.add(removeLastFeet);
		accountMenu.add(save);
		menuBar.add(accountMenu);

		// הוספת התפריט הראשי לחלון
		setJMenuBar(menuBar);

		// שאר ההגדרות של חלון התוכנה
		setTitle("FeedMe Application");
		setSize(800, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);

		mainPanel = new JPanel(new BorderLayout());
		leftPanel = new JPanel(new GridLayout(0, 1));
		removeLastFeet.addActionListener(this);
		save.addActionListener(this);

		upper = new JPanel(new BorderLayout());
		upper.add(txtAddURL, BorderLayout.NORTH);
		mainPanel.add(upper, BorderLayout.NORTH);

		middle = new JPanel(new GridLayout(7, 2));
		middle.setPreferredSize(new Dimension(1000, 3000));
		middle.validate();

		scroller = new JScrollPane(middle, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		mainPanel.add(scroller, BorderLayout.CENTER);
		mainPanel.add(leftPanel, BorderLayout.WEST);

		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

		setContentPane(mainPanel);
		setExtendedState(JFrame.MAXIMIZED_BOTH);

		client.writeUserObjectToServer(userObject);
		userObject = client.readUserObjectFromServer();
		/*if (userObject.getFeedCategoryVec() != null)
			initializeTree(userObject);*/

// בתוך הבנאי של FeedMeApp - יצירת שדה החיפוש והכפתור והוספתם ל-upper panel
		searchField = new JTextField(20); // שדה טקסט עם אורך של 20 תווים
		searchButton = new JButton("Search");

// הוספת Listener לכפתור החיפוש
		searchButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				datapanelVec.removeAllElements();
				middle.removeAll();

				for (int i = 0; i < userObject.getFeedCategoryVec().size(); i++)
					for (int j = 0; j < userObject.getFeedCategoryVec().get(i).getFeedDetailsObjectVec().size(); j++) {
						// userObject.getFeedCategoryVec().get(i).getFeedDetailsObjectVec().get(j)

						datapanelVec.addElement(new DataChannelPanel(
								userObject.getFeedCategoryVec().get(i).getFeedDetailsObjectVec().get(j).getFeedURL(),
								searchField.getText()));
						if (datapanelVec.lastElement().hasFeeds())
							middle.add(datapanelVec.lastElement(), BorderLayout.NORTH);
						validate();
					}

			}
		});

		// הוספת שדה החיפוש והכפתור לפאנל העליון
		JPanel searchPanel = new JPanel();
		searchPanel.add(searchField);
		searchPanel.add(searchButton);
		upper.add(searchPanel, BorderLayout.NORTH); // מיקום הפאנל העליון


		setVisible(true);

		userObject = new LoginWindow(this, "Login", userObject).getUserObject();
		client.writeUserObjectToServer(userObject);
		userObject = client.readUserObjectFromServer();



		while(userObject.getStatus().equals("wrong username or password")){
			JOptionPane.showMessageDialog(this, "wrong username or password");
			userObject = new LoginWindow(this, "Login", userObject).getUserObject();
			client.writeUserObjectToServer(userObject);
			userObject = client.readUserObjectFromServer();
		}




		if (userObject.getStatus().equals("Register")) {
			userObject = new RegisterWindow(this, "Register", userObject).getUserObject();
			client.writeUserObjectToServer(userObject);
			userObject = client.readUserObjectFromServer();
			while(!userObject.getStatus().equals("user registered")){
				JOptionPane.showMessageDialog(this,
						"This username already exists. Please choose a different username.",
						"Username Taken", JOptionPane.ERROR_MESSAGE);
				userObject = new RegisterWindow(this, "Register", userObject).getUserObject();
				client.writeUserObjectToServer(userObject);
				userObject = client.readUserObjectFromServer();
			}
		}
		System.out.println("running...");
		// userObject = new UserObject(user, password, action);
		System.out.println(userObject);

		//client.writeUserObjectToServer(userObject);
		//userObject = client.readUserObjectFromServer();




		if (userObject.getFeedCategoryVec() != null)
			initializeTree(userObject);


	}

	private void deleteAccount() {
		int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete the account?");
		if (confirm == JOptionPane.YES_OPTION) {
			deleteUser(); // קריאה לפונקציה שמוחקת את המשתמש
			JOptionPane.showMessageDialog(this, "Your account has been deleted");
			// ביצוע פעולות נוספות אם יש צורך, כמו לסגור את התוכנית או להחזיר למסך כניסה
			userObject.setUsername("default");
			userObject.setPassword("1");
			userObject.setStatus("login");
			client.writeUserObjectToServer(userObject);
			userObject = client.readUserObjectFromServer();
			initializeTree(userObject);

		}
	}

	private void deleteUser() {
		// הלוגיקה למחיקת המשתמש
		// כאן תמומש מחיקת פרטי המשתמש מהמסד נתונים או מקובץ
		userObject.setStatus("Delete Account");
		client.writeUserObjectToServer(userObject);
		userObject = client.readUserObjectFromServer();

	}

	public void removeLast(){
		if (datapanelVec.size() != 0) {
			middle.remove(datapanelVec.lastElement());
			datapanelVec.remove(datapanelVec.lastElement());
			middle.validate();
			middle.repaint();
		}
	}

	public void saveFeeds(){
		Vector<FeedCategory> userObjectFeedCategoryVec = userObject.getFeedCategoryVec();
		if (userObjectFeedCategoryVec != null) {
			userObjectFeedCategoryVec.removeAllElements();
			System.out.println(userObject + "remove");
		}

		traverseTree(root);
		System.out.println(userObject.getFeedCategoryVec());
		userObject.setStatus("save");
		client.writeUserObjectToServer(userObject);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if (removeLastFeet == e.getSource()) {
			if (datapanelVec.size() != 0) {
				middle.remove(datapanelVec.lastElement());
				datapanelVec.remove(datapanelVec.lastElement());
				middle.validate();
				middle.repaint();
			}
		} else if (save == e.getSource()) {
			Vector<FeedCategory> userObjectFeedCategoryVec = userObject.getFeedCategoryVec();
			if (userObjectFeedCategoryVec != null) {
				userObjectFeedCategoryVec.removeAllElements();
				System.out.println(userObject + "remove");
			}

			traverseTree(root);
			System.out.println(userObject.getFeedCategoryVec());
			userObject.setStatus("save");
			client.writeUserObjectToServer(userObject);
		}
	}

	public void initializeTree(UserObject uo) {
		root = new DefaultMutableTreeNode(uo.getUsername() + "'s " + "feeds");
		DefaultMutableTreeNode dmtn;
		for (int i = 0; i < uo.getFeedCategoryVec().size(); i++) {
			dmtn = new DefaultMutableTreeNode(uo.getFeedCategoryVec().get(i).getCategoryName());
			root.add(dmtn);
			for (int j = 0; j < uo.getFeedCategoryVec().elementAt(i).getFeedDetailsObjectVec().size(); j++) {
				dmtn.add(new DefaultMutableTreeNode(
						uo.getFeedCategoryVec().elementAt(i).getFeedDetailsObjectVec().elementAt(j).getFeedURL()));
			}
		}

		tree = new JTree(root);
		DefaultTreeCellRenderer renderer = (DefaultTreeCellRenderer) tree.getCellRenderer();
		renderer.setFont(new Font("Arial", Font.PLAIN, 20));
		tree.setCellRenderer(renderer);
		leftPanel.add(tree);

		// הגדרת Drag and Drop עבור העץ
		tree.setDragEnabled(true);
		tree.setDropMode(DropMode.ON_OR_INSERT);
		tree.setTransferHandler(new TreeTransferHandler());

		// יצירת תפריט לחיצה ימנית עם אפשרות מחיקה
		JPopupMenu popupMenu = new JPopupMenu();
		JMenuItem deleteItem = new JMenuItem("Delete Node");
		deleteItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				deleteSelectedNode(); // קריאה לפונקציית מחיקת ענף נבחר
			}
		});
		popupMenu.add(deleteItem);

		// rename
		JMenuItem renameItem = new JMenuItem("Rename");
		renameItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				renameSelectedNode();
			}
		});
		popupMenu.add(renameItem);

		// add category
		JMenuItem addCategoryItem = new JMenuItem("Add category");
		addCategoryItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				addCategory();
			}
		});
		popupMenu.add(addCategoryItem);

// פריט חדש בתפריט ההקשרי להוספת פיד
		JMenuItem addFeedItem = new JMenuItem("Add Feed");
		addFeedItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addFeedToCategory(); // קריאה לפונקציה להוספת פיד לקטגוריה
			}
		});
		popupMenu.add(addFeedItem);

		tree.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (SwingUtilities.isRightMouseButton(e)) {
					int row = tree.getClosestRowForLocation(e.getX(), e.getY());
					tree.setSelectionRow(row);
					popupMenu.show(tree, e.getX(), e.getY());
				}
			}

			public void mouseClicked(MouseEvent me) {
				Object nodeInfo = null;
				DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
				if (node != null && node.isLeaf()) {
					nodeInfo = node.getUserObject();
					System.out.println(nodeInfo.toString());
					datapanelVec.addElement(new DataChannelPanel(nodeInfo.toString()));
					middle.add(datapanelVec.lastElement(), BorderLayout.NORTH);
					validate();
				}
			}
		});
	}

	private void renameSelectedNode() {
		TreePath selectedPath = tree.getSelectionPath();
		if (selectedPath == null) {
			JOptionPane.showMessageDialog(this, "Please select a node to rename.");
			return;
		}

		DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) selectedPath.getLastPathComponent();
		String currentName = selectedNode.getUserObject().toString();
		String newName = JOptionPane.showInputDialog(this, "Enter new name:", currentName);

		if (newName != null && !newName.trim().isEmpty()) {
			selectedNode.setUserObject(newName);
			DefaultTreeModel model = (DefaultTreeModel) tree.getModel();
			model.nodeChanged(selectedNode); // עדכון המודל להצגת השם החדש
		} else {
			JOptionPane.showMessageDialog(this, "Invalid name. Please try again.");
		}
	}

	private void addCategory() {
		String categoryName = JOptionPane.showInputDialog(this, "Enter name for new category:");

		if (categoryName != null && !categoryName.trim().isEmpty()) {
			DefaultMutableTreeNode parentNode;

			TreePath selectedPath = tree.getSelectionPath();

			parentNode = root; // אם אין בחירה, נוסיף לשורש

			DefaultMutableTreeNode newCategoryNode = new DefaultMutableTreeNode(categoryName);
			DefaultTreeModel model = (DefaultTreeModel) tree.getModel();

			// הוספת הקטגוריה החדשה למבנה הנתונים
			model.insertNodeInto(newCategoryNode, parentNode, parentNode.getChildCount());

			// הרחבת הקטגוריה ההורה כדי להציג את הקטגוריה החדשה
			tree.expandPath(new TreePath(parentNode.getPath()));
		} else {
			JOptionPane.showMessageDialog(this, "Invalid category name. Please try again.");
		}
	}

	private void addFeedToCategory() {
		TreePath selectedPath = tree.getSelectionPath();
		if (selectedPath == null) {
			JOptionPane.showMessageDialog(this, "Please select a category to add a feed.");
			return;
		}

		DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) selectedPath.getLastPathComponent();

		// בדיקת אם ה-Node הנבחר הוא קטגוריה (ולא הענף הראשי)
		if (selectedNode == root) {
			JOptionPane.showMessageDialog(this, "You cannot add a feed to the root node. Please select a category.");
			return;
		}

		// בקשת שם הפיד מהמשתמש
		String feedName = JOptionPane.showInputDialog(this, "Enter name for new feed:");
		if (feedName == null || feedName.trim().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Feed name cannot be empty.");
			return;
		}

		// יצירת פיד חדש כ-Node והוספתו לקטגוריה הנבחרת
		DefaultMutableTreeNode newFeedNode = new DefaultMutableTreeNode(feedName);
		selectedNode.add(newFeedNode);

		// עדכון המודל להצגת השינויים בעץ
		((DefaultTreeModel) tree.getModel()).reload(selectedNode);
	}

	private void deleteSelectedNode() {
		TreePath selectedPath = tree.getSelectionPath();
		if (selectedPath != null) {
			DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) selectedPath.getLastPathComponent();
			if (selectedNode.getParent() != null) {
				DefaultTreeModel model = (DefaultTreeModel) tree.getModel();
				model.removeNodeFromParent(selectedNode);
			} else {
				JOptionPane.showMessageDialog(this, "Cannot delete the root node.");
			}
		} else {
			JOptionPane.showMessageDialog(this, "Please select a node to delete.");
		}
	}

	public static void traverseTree(DefaultMutableTreeNode root) {
		Enumeration<TreeNode> e = root.preorderEnumeration();
		while (e.hasMoreElements()) {
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) e.nextElement();
			if (node.toString().equals(userObject.getUsername() + "'s feeds"))
				continue;

			if (node.isLeaf()) {
				System.out.println("add feed: " + node.toString());
				userObject.getFeedCategoryVec().lastElement()
						.addFeedDetailsObject2Vec(new FeedDetailsObject("", node.toString()));
			} else {
				System.out.println("add category: " + node.toString());
				userObject.getFeedCategoryVec().add(new FeedCategory(node.toString()));
			}
		}
		System.out.println(userObject);
	}

	// פונקציית עזר לבדיקת קיום קטגוריה לפי שם
	private static boolean containsCategory(Vector<FeedCategory> categories, String categoryName) {
		for (FeedCategory category : categories) {
			if (category.getCategoryName().equals(categoryName)) {
				return true;
			}
		}
		return false;
	}

	public static void main(String args[]) {
		FeedMeApp rt = new FeedMeApp("FeedMe App");
	}

	// מחלקת TransferHandler מותאמת אישית לגרירה ושחרור של Nodes בתוך JTree
	class TreeTransferHandler extends TransferHandler {
		private DefaultMutableTreeNode draggedNode;

		public int getSourceActions(JComponent c) {
			return MOVE;
		}

		@Override
		protected Transferable createTransferable(JComponent c) {
			JTree tree = (JTree) c;
			draggedNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent(); // שמירת הענף שנגרר
			return new StringSelection(draggedNode.toString());
		}

		@Override
		public boolean canImport(TransferHandler.TransferSupport support) {
			if (!support.isDrop())
				return false;
			support.setShowDropLocation(true);

			JTree.DropLocation dropLocation = (JTree.DropLocation) support.getDropLocation();
			TreePath path = dropLocation.getPath();

			// בדיקה שה-Node אליו גוררים קיים ולא מדובר בצאצא של עצמו
			return path != null && draggedNode != null
					&& !draggedNode.isNodeAncestor((DefaultMutableTreeNode) path.getLastPathComponent());
		}

		@Override
		public boolean importData(TransferHandler.TransferSupport support) {
			if (!canImport(support))
				return false;

			JTree.DropLocation dropLocation = (JTree.DropLocation) support.getDropLocation();
			TreePath destinationPath = dropLocation.getPath();
			DefaultMutableTreeNode newParentNode = (DefaultMutableTreeNode) destinationPath.getLastPathComponent();

			// ביצוע ההעברה של הענף הנגרר לקטגוריה החדשה
			DefaultTreeModel model = (DefaultTreeModel) tree.getModel();
			model.removeNodeFromParent(draggedNode); // הסרתו מהמיקום הישן
			model.insertNodeInto(draggedNode, newParentNode, newParentNode.getChildCount()); // הוספתו לקטגוריה החדשה

			// הרחבת ה-Node החדש להצגת הענף שהתווסף
			tree.expandPath(destinationPath);
			tree.setSelectionPath(new TreePath(draggedNode.getPath()));

			return true;
		}
	}
}